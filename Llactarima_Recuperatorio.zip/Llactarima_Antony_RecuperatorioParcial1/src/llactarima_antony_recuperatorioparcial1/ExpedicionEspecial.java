
package llactarima_antony_recuperatorioparcial1;
import java.util.List;
import java.util.ArrayList;

public class ExpedicionEspecial {
    List<Nave> naves = new ArrayList();
    
    public void agregarNave(Nave naveNueva){
        if(naveNueva == null){
            System.out.println("Nave Invalida");
        }else if(naves.contains(naveNueva)){
            throw new NaveRepetidaException();
        }else{
            naves.add(naveNueva);
        }
    }
    
    public void mostrarNaves(){
        for(Nave n : naves){
            System.out.println(n);
        }
    }
    
    public void iniciarExploracion(){
        for(Nave n : naves){
            n.explorar();
        }
    }
    
}
