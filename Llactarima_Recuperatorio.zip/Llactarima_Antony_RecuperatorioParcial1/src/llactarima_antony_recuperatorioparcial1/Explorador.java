
package llactarima_antony_recuperatorioparcial1;


public interface Explorador {
    
    public void explorar();
}
