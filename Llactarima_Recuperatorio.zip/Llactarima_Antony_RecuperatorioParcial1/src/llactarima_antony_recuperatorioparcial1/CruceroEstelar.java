
package llactarima_antony_recuperatorioparcial1;


public class CruceroEstelar extends Nave{
    
    private final int CAPACIDADPASAJEROSMAX = 100;
    private final int CAPACIDADPASAJEROSMIN = 50;
    private int cantidadPasajeros;
    
    
    public CruceroEstelar(String nombre, int capacidadTripulacion, int anioLanzamiento, int cantidadPasajeros){
        super(nombre, capacidadTripulacion, anioLanzamiento);
        if(cantidadPasajeros < CAPACIDADPASAJEROSMIN || cantidadPasajeros > CAPACIDADPASAJEROSMAX){
            this.cantidadPasajeros = -1;
        }else{
            this.cantidadPasajeros = cantidadPasajeros;
        }
    }
    
    @Override
    public void explorar(){
        System.out.println("Esta nave no puede realiazar la exploracion.Solo transporta pasajeros");
    }
        
}
