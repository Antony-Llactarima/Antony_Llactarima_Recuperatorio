
package llactarima_antony_recuperatorioparcial1;


public abstract class Nave implements Explorador{
    private String nombre;
    private int capacidadTripulacion;
    private int anioLanzamiento;
    
    public Nave(String nombre, int capacidadTripulacion, int anioLanzamiento){
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }
    
    
    @Override
    public boolean equals(Object objeto){
        if (this == objeto) {
            return true;
        }
        
        if (objeto == null) {
            return false;
        }
        
        Nave otraNave = (Nave) objeto;
        return this.nombre.equals(otraNave.nombre) && this.anioLanzamiento == otraNave.anioLanzamiento;
    }
    
    @Override
    public String toString(){
        return "Nombre: "+ nombre +"| Capacidad Tripulacion: "+ capacidadTripulacion +"|Anio lanzamiento: "+ anioLanzamiento;
    }
    
    @Override
    public void explorar(){
        System.out.println("La exploracion a iniciado.");
    }

    
}
