
package llactarima_antony_recuperatorioparcial1;


public class NaveExploracion extends Nave{
    private Mision tipoMision;
    
    public NaveExploracion(String nombre, int capacidadTripulacion, int anioLanzamiento, Mision tipoMision){
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.tipoMision = tipoMision;
    }
    
    
}
