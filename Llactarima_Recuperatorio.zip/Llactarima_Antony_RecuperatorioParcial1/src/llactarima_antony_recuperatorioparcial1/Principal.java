
package llactarima_antony_recuperatorioparcial1;


public class Principal {

    public static void main(String[] args) {
        ExpedicionEspecial ExEs = new ExpedicionEspecial();
        
        Nave n1 = new NaveExploracion("Apolo1", 10, 2004,Mision.CONTACTO);
        Nave n2 = new Carguero("Apolo2", 10, 2004, 200);
        Nave n3 = new CruceroEstelar("Apolo3", 10, 2004, 60);
        Nave n4 = new CruceroEstelar("Apolo1", 20, 2004, 50);
                
        
        agregarNuevaNave(ExEs, n1);
        agregarNuevaNave(ExEs, n2);
        agregarNuevaNave(ExEs, n3);
        agregarNuevaNave(ExEs, n4);
        
        ExEs.iniciarExploracion();
    }
    
    public static void agregarNuevaNave(ExpedicionEspecial agencia, Nave nuevaNave){
        try{
            agencia.agregarNave(nuevaNave);
        } catch(NaveRepetidaException e){
            System.out.println(e.getMessage());
        }
    }
    
}
