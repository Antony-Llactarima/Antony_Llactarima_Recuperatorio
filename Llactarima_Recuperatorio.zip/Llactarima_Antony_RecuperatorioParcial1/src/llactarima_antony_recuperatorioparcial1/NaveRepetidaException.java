
package llactarima_antony_recuperatorioparcial1;


public class NaveRepetidaException extends RuntimeException {
    private static String MESSAGE = "Nave ingresada repetida.";
    
    public NaveRepetidaException(){
        super(MESSAGE);
    }

    
}
