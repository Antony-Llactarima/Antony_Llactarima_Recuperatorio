/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package llactarima_antony_recuperatorioparcial1;

/**
 *
 * @author anton
 */
public class Carguero extends Nave{
    private final int CAPACIDADCARGAMAX = 500;
    private final int CAPACIDADCARGAMIN = 100;
    private int cargaToneladas;
    
    public Carguero(String nombre, int capacidadTripulacion, int anioLanzamiento, int carga){
        super(nombre, capacidadTripulacion, anioLanzamiento);
        if(carga < CAPACIDADCARGAMIN || carga > CAPACIDADCARGAMAX){
            this.cargaToneladas = -1;
        }else{
            this.cargaToneladas = carga;
        }
    }

    
}
